let timerE1 = document.getElementById("timer");
let defuserE1 = document.getElementById("defuser");

defuserE1.addEventListener("keydown", function(event) {
    let bombText = defuserE1.value;
    if (event.key === "Enter" && bombText === "Defuse" && countdown !== 0) {
        timerE1.textContent = "You Did a great Job!";
        console.log(event.key);
        clearInterval(intervalId);
    } else {
        timerE1.textContent = "You Failed!";
    }
})

let countdown = 10;
let intervalId = setInterval(function() {
    countdown = countdown - 1;
    timerE1.textContent = countdown;
    if (countdown === 0) {
        timerE1.textContent = "boom!";
        clearInterval(intervalId);
    }

}, 1000)